mport React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider } from '@/contexts/AuthContext';
import LoginPage from '@/pages/LoginPage';
import Dashboard from '@/pages/Dashboard';
import ProjectsPage from '@/pages/ProjectsPage';
import AboutPage from '@/pages/AboutPage';
import ContactPage from '@/pages/ContactPage';
import CalendarPage from '@/pages/CalendarPage';
import ProfilePage from '@/pages/ProfilePage';
import AdminPanel from '@/pages/AdminPanel';
import ProtectedRoute from '@/components/ProtectedRoute';
import PortfolioPage from '@/pages/PortfolioPage';
import UploadProjectPage from '@/pages/UploadProjectPage';
import SearchStudentsPage from '@/pages/SearchStudentsPage';
import ProgressReportPage from '@/pages/ProgressReportPage';
import LandingPage from '@/pages/LandingPage';
import MusicPage from '@/pages/MusicPage';

function App() {
  return (
    <>
      <Helmet>
        <title>Portofolio PBL - Politeknik Negeri Batam</title>
        <meta name="description" content="Platform portofolio digital untuk mahasiswa dan dosen Politeknik Negeri Batam dalam mendokumentasikan proyek-proyek PBL" />
        <meta property="og:title" content="Portofolio PBL - Politeknik Negeri Batam" />
        <meta property="og:description" content="Platform portofolio digital untuk mahasiswa dan dosen Politeknik Negeri Batam dalam mendokumentasikan proyek-proyek PBL" />
      </Helmet>
      
      <AuthProvider>
        <Router>
          <div className="min-h-screen">
            <Routes>
              <Route path="/" element={<LandingPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route 
                path="/dashboard" 
                element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/projects" 
                element={
                  <ProtectedRoute>
                    <ProjectsPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/about" 
                element={
                  <ProtectedRoute>
                    <AboutPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/contact" 
                element={
                  <ProtectedRoute>
                    <ContactPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/calendar" 
                element={
                  <ProtectedRoute>
                    <CalendarPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/profile" 
                element={
                  <ProtectedRoute>
                    <ProfilePage />
                  </ProtectedRoute>
                } 
              />
               <Route 
                path="/portfolio" 
                element={
                  <ProtectedRoute>
                    <PortfolioPage />
                  </ProtectedRoute>
                } 
              />
               <Route 
                path="/upload-project" 
                element={
                  <ProtectedRoute>
                    <UploadProjectPage />
                  </ProtectedRoute>
                } 
              />
               <Route 
                path="/search-students" 
                element={
                  <ProtectedRoute>
                    <SearchStudentsPage />
                  </ProtectedRoute>
                } 
              />
               <Route 
                path="/progress-report" 
                element={
                  <ProtectedRoute>
                    <ProgressReportPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/music" 
                element={
                  <ProtectedRoute>
                    <MusicPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/admin" 
                element={
                  <ProtectedRoute adminOnly>
                    <AdminPanel />
                  </ProtectedRoute>
                } 
              />
            </Routes>
          </div>
          <Toaster />
        </Router>
      </AuthProvider>
    </>
  );
}

export default App;