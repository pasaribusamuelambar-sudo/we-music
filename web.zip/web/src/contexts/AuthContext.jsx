import React, { createContext, useContext, useState, useEffect } from 'react';
import { toast } from '@/components/ui/use-toast';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('pbl_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const login = async (emailOrNim, password, userType) => {
    try {
      let userData = {};
      let name = 'Pengguna';

      if (userType === 'mahasiswa' || userType === 'alumni') {
        const nimPattern = /^\d{10}$/;
        if (!nimPattern.test(emailOrNim)) {
          throw new Error('NIM harus berupa 10 digit angka');
        }
        if (emailOrNim !== password) {
          throw new Error('Password harus sama dengan NIM Anda');
        }
        name = userType === 'mahasiswa' ? 'Mahasiswa Polibatam' : 'Alumni Polibatam';
        userData = {
          email: `${emailOrNim}@student.polibatam.ac.id`,
          nim: emailOrNim,
        };
      } else if (userType === 'dosen') {
        const nidPattern = /^\d{8,12}$/;
        if (!nidPattern.test(password)) {
          throw new Error('Nomor Induk Dosen tidak valid');
        }
        name = 'Dosen Polibatam';
        userData = {
          email: emailOrNim,
          nid: password,
        };
      } else if (userType === 'umum') {
        name = 'Pengguna Umum';
        userData = { email: emailOrNim };
      } else if (userType === 'admin') {
        // Simple check for admin demo
        if (emailOrNim !== 'admin@polibatam.ac.id' || password !== 'admin123') {
          throw new Error('Email atau Password Admin salah');
        }
        name = 'Super Admin';
        userData = { email: emailOrNim, isAdmin: true };
      }

      const finalUserData = {
        id: Date.now(),
        name,
        userType,
        isAdmin: userType === 'admin',
        avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=3b82f6&color=fff`,
        ...userData
      };

      setUser(finalUserData);
      localStorage.setItem('pbl_user', JSON.stringify(finalUserData));
      
      toast({
        title: "Login Berhasil!",
        description: `Selamat datang, ${finalUserData.name}`,
      });

      return finalUserData;
    } catch (error) {
      toast({
        title: "Login Gagal",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }
  };

  const socialLogin = async (provider, userType) => {
    try {
      const name = userType === 'umum' ? 'Pengguna Umum' : 'Mahasiswa Polibatam';
      const userData = {
        id: Date.now(),
        email: `${userType}@${provider.toLowerCase()}.com`,
        name: name,
        userType,
        isAdmin: false,
        avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=3b82f6&color=fff`
      };

      setUser(userData);
      localStorage.setItem('pbl_user', JSON.stringify(userData));
      
      toast({
        title: `Login dengan ${provider} Berhasil!`,
        description: `Selamat datang, ${userData.name}`,
      });

      return userData;
    } catch (error) {
      toast({
        title: `Login ${provider} Gagal`,
        description: `Terjadi kesalahan saat login dengan ${provider}`,
        variant: "destructive",
      });
      throw error;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('pbl_user');
    toast({
      title: "Logout Berhasil",
      description: "Anda telah keluar dari sistem",
    });
  };

  const value = {
    user,
    login,
    socialLogin,
    logout,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};