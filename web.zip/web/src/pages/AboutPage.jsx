import React from 'react';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { GraduationCap, Target, Users, Award, BookOpen, Lightbulb } from 'lucide-react';

const AboutPage = () => {
  const features = [
    {
      icon: Target,
      title: 'Tujuan Platform',
      description: 'Menyediakan ruang digital bagi mahasiswa untuk mendokumentasikan dan memamerkan proyek-proyek PBL mereka sebagai portofolio profesional.',
      color: 'bg-blue-500',
    },
    {
      icon: Users,
      title: 'Kolaborasi Tim',
      description: 'Memfasilitasi kerjasama antara mahasiswa dan dosen dalam pengembangan proyek dengan sistem feedback dan penilaian terintegrasi.',
      color: 'bg-green-500',
    },
    {
      icon: BookOpen,
      title: 'Pembelajaran Aktif',
      description: 'Mendukung metode Problem Based Learning dengan tools untuk tracking progress dan dokumentasi proses pembelajaran.',
      color: 'bg-purple-500',
    },
    {
      icon: Award,
      title: 'Penilaian Komprehensif',
      description: 'Sistem penilaian yang memungkinkan dosen memberikan feedback konstruktif dan penilaian yang objektif.',
      color: 'bg-orange-500',
    },
  ];

  const stats = [
    { label: 'Mahasiswa Aktif', value: '2,500+', icon: GraduationCap },
    { label: 'Proyek Selesai', value: '1,200+', icon: Target },
    { label: 'Dosen Pembimbing', value: '150+', icon: Users },
    { label: 'Program Studi', value: '12', icon: BookOpen },
  ];

  const technologies = [
    'React.js', 'Node.js', 'Express.js', 'MongoDB', 'PostgreSQL', 
    'Python', 'Java', 'PHP', 'Laravel', 'Vue.js', 'Angular', 
    'Flutter', 'React Native', 'Docker', 'AWS', 'Firebase'
  ];

  return (
    <Layout>
      <div className="space-y-8">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-4"
        >
          <h1 className="text-4xl font-bold text-gray-900">Tentang Platform PBL</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Platform digital inovatif untuk mendokumentasikan, mengelola, dan memamerkan 
            proyek-proyek Problem Based Learning di Politeknik Negeri Batam
          </p>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6"
        >
          {stats.map((stat, index) => (
            <Card key={stat.label} className="text-center">
              <CardContent className="p-6">
                <stat.icon className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        {/* Features */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Fitur Utama Platform</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${feature.color}`}>
                        <feature.icon className="h-6 w-6 text-white" />
                      </div>
                      <CardTitle className="text-lg">{feature.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-gray-600">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* About PBL Method */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-lg bg-indigo-500">
                  <Lightbulb className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-xl">Apa itu Problem Based Learning (PBL)?</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600">
                Problem Based Learning (PBL) adalah metode pembelajaran yang menggunakan masalah dunia nyata 
                sebagai konteks bagi mahasiswa untuk belajar tentang cara berpikir kritis dan keterampilan 
                pemecahan masalah, serta untuk memperoleh pengetahuan dan konsep yang esensial dari materi kuliah.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-900 mb-2">Identifikasi Masalah</h4>
                  <p className="text-sm text-blue-700">
                    Mahasiswa mengidentifikasi masalah nyata yang perlu diselesaikan
                  </p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-green-900 mb-2">Pengembangan Solusi</h4>
                  <p className="text-sm text-green-700">
                    Tim mengembangkan solusi inovatif menggunakan teknologi terkini
                  </p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-purple-900 mb-2">Implementasi & Evaluasi</h4>
                  <p className="text-sm text-purple-700">
                    Solusi diimplementasikan dan dievaluasi untuk perbaikan berkelanjutan
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Technologies */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Teknologi yang Digunakan dalam Proyek PBL</CardTitle>
              <CardDescription>
                Berbagai teknologi modern yang dipelajari dan diimplementasikan dalam proyek-proyek PBL
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {technologies.map((tech, index) => (
                  <motion.div
                    key={tech}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.6 + index * 0.05 }}
                  >
                    <Badge variant="secondary" className="text-sm py-1 px-3">
                      {tech}
                    </Badge>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Vision & Mission */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-blue-600">Visi</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Menjadi platform terdepan dalam mendukung pembelajaran berbasis masalah yang menghasilkan 
                lulusan yang kompeten, inovatif, dan siap menghadapi tantangan industri 4.0.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-green-600">Misi</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-gray-600 space-y-2">
                <li>• Menyediakan platform digital yang user-friendly untuk dokumentasi proyek PBL</li>
                <li>• Memfasilitasi kolaborasi antara mahasiswa, dosen, dan industri</li>
                <li>• Mendorong inovasi dan kreativitas dalam pemecahan masalah</li>
                <li>• Membangun portofolio digital yang berkualitas untuk mahasiswa</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        {/* Contact Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">Politeknik Negeri Batam</h3>
              <p className="text-blue-100 mb-4">
                Jl. Ahmad Yani, Batam Centre, Batam 29461, Kepulauan Riau, Indonesia
              </p>
              <div className="flex flex-wrap justify-center gap-4 text-sm">
                <span>📞 (0778) 469858</span>
                <span>📧 info@polibatam.ac.id</span>
                <span>🌐 www.polibatam.ac.id</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
};

export default AboutPage;