import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, 
  FolderOpen, 
  Settings, 
  BarChart3, 
  Shield, 
  Search,
  Filter,
  Download,
  Upload,
  Eye,
  Edit,
  Trash2,
  UserPlus,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  Calendar,
  Mail
} from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const AdminPanel = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');

  const stats = [
    {
      title: 'Total Pengguna',
      value: '2,847',
      change: '+12%',
      trend: 'up',
      icon: Users,
      color: 'bg-blue-500',
    },
    {
      title: 'Proyek Aktif',
      value: '1,234',
      change: '+8%',
      trend: 'up',
      icon: FolderOpen,
      color: 'bg-green-500',
    },
    {
      title: 'Proyek Selesai',
      value: '856',
      change: '+15%',
      trend: 'up',
      icon: CheckCircle,
      color: 'bg-purple-500',
    },
    {
      title: 'Tingkat Aktivitas',
      value: '94%',
      change: '+3%',
      trend: 'up',
      icon: TrendingUp,
      color: 'bg-orange-500',
    },
  ];

  const users = [
    {
      id: 1,
      name: 'Ahmad Rizki Pratama',
      email: 'ahmad.rizki@student.polibatam.ac.id',
      type: 'mahasiswa',
      nim: '1234567890',
      status: 'active',
      lastLogin: '2024-01-10',
      projects: 5,
      avatar: 'https://ui-avatars.com/api/?name=Ahmad+Rizki&background=3b82f6&color=fff'
    },
    {
      id: 2,
      name: 'Dr. Ir. Suharto, M.T.',
      email: 'suharto@polibatam.ac.id',
      type: 'dosen',
      nid: '12345678',
      status: 'active',
      lastLogin: '2024-01-09',
      projects: 12,
      avatar: 'https://ui-avatars.com/api/?name=Dr+Suharto&background=10b981&color=fff'
    },
    {
      id: 3,
      name: 'Siti Nurhaliza',
      email: 'siti.nurhaliza@student.polibatam.ac.id',
      type: 'mahasiswa',
      nim: '1234567891',
      status: 'inactive',
      lastLogin: '2024-01-05',
      projects: 3,
      avatar: 'https://ui-avatars.com/api/?name=Siti+Nurhaliza&background=8b5cf6&color=fff'
    },
    {
      id: 4,
      name: 'Prof. Dr. Bambang Wijaya',
      email: 'bambang.wijaya@polibatam.ac.id',
      type: 'dosen',
      nid: '12345679',
      status: 'active',
      lastLogin: '2024-01-10',
      projects: 8,
      avatar: 'https://ui-avatars.com/api/?name=Prof+Bambang&background=f59e0b&color=fff'
    },
  ];

  const projects = [
    {
      id: 1,
      title: 'Sistem Manajemen Perpustakaan',
      author: 'Ahmad Rizki Pratama',
      status: 'completed',
      semester: 'Semester 6',
      submittedDate: '2024-01-08',
      grade: 'A',
      technologies: ['React', 'Node.js', 'MySQL']
    },
    {
      id: 2,
      title: 'E-Commerce UMKM Batam',
      author: 'Siti Nurhaliza',
      status: 'in-review',
      semester: 'Semester 6',
      submittedDate: '2024-01-09',
      grade: null,
      technologies: ['Vue.js', 'Laravel', 'PostgreSQL']
    },
    {
      id: 3,
      title: 'IoT Smart Home System',
      author: 'Budi Santoso',
      status: 'in-progress',
      semester: 'Semester 7',
      submittedDate: null,
      grade: null,
      technologies: ['Arduino', 'Python', 'MQTT']
    },
  ];

  const recentActivities = [
    {
      id: 1,
      type: 'user_registration',
      message: 'Mahasiswa baru mendaftar: Dewi Sartika',
      timestamp: '2024-01-10 14:30',
      icon: UserPlus,
      color: 'text-green-600'
    },
    {
      id: 2,
      type: 'project_submission',
      message: 'Proyek baru disubmit: Mobile Banking App',
      timestamp: '2024-01-10 13:15',
      icon: Upload,
      color: 'text-blue-600'
    },
    {
      id: 3,
      type: 'system_alert',
      message: 'Server maintenance dijadwalkan untuk malam ini',
      timestamp: '2024-01-10 12:00',
      icon: AlertTriangle,
      color: 'text-orange-600'
    },
    {
      id: 4,
      type: 'grade_update',
      message: 'Nilai proyek diperbarui untuk 5 mahasiswa',
      timestamp: '2024-01-10 10:45',
      icon: CheckCircle,
      color: 'text-purple-600'
    },
  ];

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = selectedFilter === 'all' || user.type === selectedFilter;
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'inactive':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'suspended':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getProjectStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'in-review':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleAction = (action, item = null) => {
    toast({
      title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀"
    });
  };

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Panel Admin</h1>
            <p className="text-gray-600 mt-1">
              Kelola pengguna, proyek, dan sistem platform PBL
            </p>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" onClick={() => handleAction('export')}>
              <Download className="h-4 w-4 mr-2" />
              Export Data
            </Button>
            <Button onClick={() => handleAction('settings')}>
              <Settings className="h-4 w-4 mr-2" />
              Pengaturan
            </Button>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                      <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                      <p className={`text-xs ${stat.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                        {stat.change} dari bulan lalu
                      </p>
                    </div>
                    <div className={`p-3 rounded-full ${stat.color}`}>
                      <stat.icon className="h-6 w-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="users">Pengguna</TabsTrigger>
            <TabsTrigger value="projects">Proyek</TabsTrigger>
            <TabsTrigger value="analytics">Analitik</TabsTrigger>
            <TabsTrigger value="system">Sistem</TabsTrigger>
          </TabsList>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card>
                <CardHeader>
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                      <CardTitle>Manajemen Pengguna</CardTitle>
                      <CardDescription>
                        Kelola akun mahasiswa dan dosen
                      </CardDescription>
                    </div>
                    <Button onClick={() => handleAction('add-user')}>
                      <UserPlus className="h-4 w-4 mr-2" />
                      Tambah Pengguna
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {/* Search and Filter */}
                  <div className="flex flex-col sm:flex-row gap-4 mb-6">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input
                        placeholder="Cari pengguna..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant={selectedFilter === 'all' ? 'default' : 'outline'}
                        onClick={() => setSelectedFilter('all')}
                        size="sm"
                      >
                        Semua
                      </Button>
                      <Button
                        variant={selectedFilter === 'mahasiswa' ? 'default' : 'outline'}
                        onClick={() => setSelectedFilter('mahasiswa')}
                        size="sm"
                      >
                        Mahasiswa
                      </Button>
                      <Button
                        variant={selectedFilter === 'dosen' ? 'default' : 'outline'}
                        onClick={() => setSelectedFilter('dosen')}
                        size="sm"
                      >
                        Dosen
                      </Button>
                    </div>
                  </div>

                  {/* Users Table */}
                  <div className="space-y-4">
                    {filteredUsers.map((user, index) => (
                      <motion.div
                        key={user.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2 + index * 0.1 }}
                        className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <Avatar className="h-12 w-12">
                              <AvatarImage src={user.avatar} />
                              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <h4 className="font-semibold text-gray-900">{user.name}</h4>
                              <p className="text-sm text-gray-600">{user.email}</p>
                              <div className="flex items-center space-x-2 mt-1">
                                <Badge variant="outline" className="text-xs">
                                  {user.type === 'mahasiswa' ? `NIM: ${user.nim}` : `NID: ${user.nid}`}
                                </Badge>
                                <Badge className={getStatusColor(user.status)}>
                                  {user.status}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-4">
                            <div className="text-right text-sm text-gray-600">
                              <p>{user.projects} proyek</p>
                              <p>Login: {new Date(user.lastLogin).toLocaleDateString('id-ID')}</p>
                            </div>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleAction('view-user', user)}
                              >
                                <Eye className="h-3 w-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleAction('edit-user', user)}
                              >
                                <Edit className="h-3 w-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-red-600 hover:text-red-700"
                                onClick={() => handleAction('delete-user', user)}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Manajemen Proyek</CardTitle>
                  <CardDescription>
                    Monitor dan kelola semua proyek PBL
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {projects.map((project, index) => (
                      <motion.div
                        key={project.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2 + index * 0.1 }}
                        className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                      >
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-1">{project.title}</h4>
                            <p className="text-sm text-gray-600">Oleh: {project.author}</p>
                          </div>
                          <div className="flex space-x-2">
                            <Badge className={getProjectStatusColor(project.status)}>
                              {project.status}
                            </Badge>
                            {project.grade && (
                              <Badge variant="outline">
                                Nilai: {project.grade}
                              </Badge>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mb-3">
                          {project.technologies.map((tech, techIndex) => (
                            <Badge key={techIndex} variant="secondary" className="text-xs">
                              {tech}
                            </Badge>
                          ))}
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div className="text-sm text-gray-600">
                            <span>{project.semester}</span>
                            {project.submittedDate && (
                              <span className="ml-4">
                                Disubmit: {new Date(project.submittedDate).toLocaleDateString('id-ID')}
                              </span>
                            )}
                          </div>
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleAction('view-project', project)}
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              Lihat
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleAction('grade-project', project)}
                            >
                              <Edit className="h-3 w-3 mr-1" />
                              Nilai
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-6"
            >
              <Card>
                <CardHeader>
                  <CardTitle>Statistik Pengguna</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Mahasiswa Aktif</span>
                      <span className="font-semibold">2,156</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Dosen Aktif</span>
                      <span className="font-semibold">156</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Pengguna Baru (Bulan Ini)</span>
                      <span className="font-semibold text-green-600">+89</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Tingkat Retensi</span>
                      <span className="font-semibold">94%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Statistik Proyek</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Proyek Selesai</span>
                      <span className="font-semibold">856</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Proyek Dalam Review</span>
                      <span className="font-semibold">234</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Proyek Dalam Progress</span>
                      <span className="font-semibold">1,000</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Rata-rata Nilai</span>
                      <span className="font-semibold">B+</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* System Tab */}
          <TabsContent value="system" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Aktivitas Terbaru</CardTitle>
                    <CardDescription>
                      Log aktivitas sistem dan pengguna
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentActivities.map((activity, index) => {
                        const IconComponent = activity.icon;
                        return (
                          <motion.div
                            key={activity.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.2 + index * 0.1 }}
                            className="flex items-start space-x-3"
                          >
                            <div className={`p-1 rounded-full ${activity.color}`}>
                              <IconComponent className="h-4 w-4" />
                            </div>
                            <div className="flex-1">
                              <p className="text-sm text-gray-900">{activity.message}</p>
                              <p className="text-xs text-gray-500">{activity.timestamp}</p>
                            </div>
                          </motion.div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Pengaturan Sistem</CardTitle>
                    <CardDescription>
                      Konfigurasi dan maintenance sistem
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={() => handleAction('backup')}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Backup Database
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={() => handleAction('maintenance')}
                    >
                      <Settings className="h-4 w-4 mr-2" />
                      Mode Maintenance
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={() => handleAction('logs')}
                    >
                      <BarChart3 className="h-4 w-4 mr-2" />
                      Lihat Log Sistem
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={() => handleAction('security')}
                    >
                      <Shield className="h-4 w-4 mr-2" />
                      Pengaturan Keamanan
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={() => handleAction('notifications')}
                    >
                      <Mail className="h-4 w-4 mr-2" />
                      Kelola Notifikasi
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default AdminPanel;