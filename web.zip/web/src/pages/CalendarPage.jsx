import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  Users,
  AlertCircle
} from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const CalendarPage = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);
  const [isAddAgendaOpen, setIsAddAgendaOpen] = useState(false);

  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];

  const days = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];

  const [events, setEvents] = useState({
    '2025-09-15': [{ type: 'event', title: 'Deadline Proposal PBL Semester 6', time: '23:59', color: 'blue' }],
    '2025-09-20': [{ type: 'event', title: 'Seminar Proposal PBL', time: '09:00', location: 'Aula Utama', color: 'green' }],
    '2025-09-25': [{ type: 'event', title: 'Workshop IoT untuk PBL', time: '13:00', location: 'Lab Komputer 1', color: 'purple' }],
    '2025-10-10': [{ type: 'holiday', title: 'Isra Miraj', color: 'red' }],
    '2025-10-14': [{ type: 'event', title: 'Presentasi Progress PBL', time: '08:00', location: 'Ruang Kelas', color: 'orange' }],
  });

  const [upcomingEvents, setUpcomingEvents] = useState([
    {
      id: 1,
      title: 'Deadline Proposal PBL Semester 6',
      date: '2025-09-15',
      time: '23:59',
      type: 'deadline',
      description: 'Batas akhir pengumpulan proposal PBL untuk mahasiswa semester 6',
      participants: 'Mahasiswa Semester 6',
      priority: 'high'
    },
    {
      id: 2,
      title: 'Seminar Proposal PBL',
      date: '2025-09-20',
      time: '09:00',
      type: 'seminar',
      description: 'Presentasi dan diskusi proposal PBL dengan dosen pembimbing',
      location: 'Aula Utama',
      participants: 'Mahasiswa & Dosen',
      priority: 'medium'
    },
  ]);

  const getDaysInMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const formatDateKey = (year, month, day) => {
    return `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  };

  const navigateMonth = (direction) => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      newDate.setMonth(prev.getMonth() + direction);
      return newDate;
    });
  };

  const handleAddAgenda = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const newEvent = {
      title: formData.get('title'),
      date: formData.get('date'),
      time: formData.get('time'),
      location: formData.get('location'),
      description: formData.get('description'),
      type: 'event',
      color: 'blue',
    };

    if (!newEvent.title || !newEvent.date) {
      toast({ title: "Error", description: "Judul dan Tanggal harus diisi.", variant: "destructive" });
      return;
    }

    setEvents(prev => ({
      ...prev,
      [newEvent.date]: [...(prev[newEvent.date] || []), newEvent]
    }));

    setUpcomingEvents(prev => [...prev, { ...newEvent, id: Date.now(), participants: 'Tim Anda', priority: 'medium' }].sort((a, b) => new Date(a.date) - new Date(b.date)));

    toast({ title: "Agenda Ditambahkan!", description: `${newEvent.title} telah ditambahkan ke kalender.` });
    setIsAddAgendaOpen(false);
  };

  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(currentDate);
    const firstDay = getFirstDayOfMonth(currentDate);
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const calendarDays = [];

    for (let i = 0; i < firstDay; i++) {
      calendarDays.push(<div key={`empty-${i}`} className="calendar-day"></div>);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const dateKey = formatDateKey(year, month, day);
      const dayEvents = events[dateKey] || [];
      const isToday = new Date().toDateString() === new Date(year, month, day).toDateString();
      const isSelected = selectedDate === dateKey;
      const isHoliday = dayEvents.some(event => event.type === 'holiday');

      calendarDays.push(
        <motion.div
          key={day}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={`calendar-day relative ${isToday ? 'today' : ''} ${isHoliday ? 'holiday' : ''} ${isSelected ? 'bg-blue-100 border-blue-300' : ''}`}
          onClick={() => setSelectedDate(dateKey)}
        >
          <span className="text-sm font-medium">{day}</span>
          {dayEvents.length > 0 && (
            <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2">
              <div className="flex space-x-1">
                {dayEvents.slice(0, 2).map((event, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full ${
                      event.color === 'red' ? 'bg-red-500' :
                      event.color === 'blue' ? 'bg-blue-500' :
                      event.color === 'green' ? 'bg-green-500' :
                      event.color === 'purple' ? 'bg-purple-500' :
                      'bg-orange-500'
                    }`}
                  />
                ))}
                {dayEvents.length > 2 && (
                  <div className="w-2 h-2 rounded-full bg-gray-400" />
                )}
              </div>
            </div>
          )}
        </motion.div>
      );
    }

    return calendarDays;
  };

  const getEventTypeIcon = (type) => {
    switch (type) {
      case 'deadline': return AlertCircle;
      case 'seminar': return Users;
      case 'workshop': return CalendarIcon;
      case 'presentation': return Users;
      default: return CalendarIcon;
    }
  };

  const getEventTypeColor = (type) => {
    switch (type) {
      case 'deadline': return 'bg-red-100 text-red-800 border-red-200';
      case 'seminar': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'workshop': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'presentation': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <Layout>
      <div className="space-y-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Agenda PBL</h1>
            <p className="text-gray-600 mt-1">Kelola jadwal dan agenda kegiatan Problem Based Learning</p>
          </div>
          <Dialog open={isAddAgendaOpen} onOpenChange={setIsAddAgendaOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                Tambah Agenda
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Tambah Agenda Baru</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddAgenda} className="space-y-4">
                <div>
                  <Label htmlFor="title">Judul Agenda</Label>
                  <Input id="title" name="title" required />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="date">Tanggal</Label>
                    <Input id="date" name="date" type="date" required />
                  </div>
                  <div>
                    <Label htmlFor="time">Waktu</Label>
                    <Input id="time" name="time" type="time" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="location">Lokasi</Label>
                  <Input id="location" name="location" />
                </div>
                <div>
                  <Label htmlFor="description">Deskripsi</Label>
                  <Textarea id="description" name="description" />
                </div>
                <DialogFooter>
                  <DialogClose asChild>
                    <Button type="button" variant="outline">Batal</Button>
                  </DialogClose>
                  <Button type="submit">Simpan</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2"
          >
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">{months[currentDate.getMonth()]} {currentDate.getFullYear()}</CardTitle>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="icon" onClick={() => navigateMonth(-1)}><ChevronLeft className="h-4 w-4" /></Button>
                    <Button variant="outline" size="icon" onClick={() => navigateMonth(1)}><ChevronRight className="h-4 w-4" /></Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="calendar-grid mb-2">
                  {days.map(day => (<div key={day} className="text-center text-sm font-medium text-gray-500 py-2">{day}</div>))}
                </div>
                <div className="calendar-grid">{renderCalendar()}</div>
                <div className="mt-6 flex flex-wrap gap-4 text-sm">
                  <div className="flex items-center space-x-2"><div className="w-3 h-3 bg-blue-500 rounded-full"></div><span>Hari Ini</span></div>
                  <div className="flex items-center space-x-2"><div className="w-3 h-3 bg-red-500 rounded-full"></div><span>Hari Libur</span></div>
                  <div className="flex items-center space-x-2"><div className="w-3 h-3 bg-green-500 rounded-full"></div><span>Kegiatan PBL</span></div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Agenda Mendatang</CardTitle>
                <CardDescription>Kegiatan dan deadline yang akan datang</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {upcomingEvents.map((event, index) => {
                  const EventIcon = getEventTypeIcon(event.type);
                  return (
                    <motion.div
                      key={event.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 + index * 0.1 }}
                      className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => toast({ title: "Fitur detail agenda belum diimplementasikan." })}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <EventIcon className="h-4 w-4 text-gray-600" />
                          <Badge className={getEventTypeColor(event.type)}>{event.type}</Badge>
                        </div>
                        <div className={`w-2 h-2 rounded-full ${getPriorityColor(event.priority)}`} />
                      </div>
                      <h4 className="font-semibold text-gray-900 mb-1">{event.title}</h4>
                      <p className="text-sm text-gray-600 mb-2">{event.description}</p>
                      <div className="space-y-1 text-xs text-gray-500">
                        <div className="flex items-center space-x-1"><CalendarIcon className="h-3 w-3" /><span>{new Date(event.date).toLocaleDateString('id-ID')}</span></div>
                        <div className="flex items-center space-x-1"><Clock className="h-3 w-3" /><span>{event.time}</span></div>
                        {event.location && (<div className="flex items-center space-x-1"><MapPin className="h-3 w-3" /><span>{event.location}</span></div>)}
                        <div className="flex items-center space-x-1"><Users className="h-3 w-3" /><span>{event.participants}</span></div>
                      </div>
                    </motion.div>
                  );
                })}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {selectedDate && events[selectedDate] && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            <Card>
              <CardHeader>
                <CardTitle>Agenda {new Date(selectedDate).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {events[selectedDate].map((event, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className={`w-3 h-3 rounded-full ${event.color === 'red' ? 'bg-red-500' : event.color === 'blue' ? 'bg-blue-500' : event.color === 'green' ? 'bg-green-500' : event.color === 'purple' ? 'bg-purple-500' : 'bg-orange-500'}`} />
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{event.title}</h4>
                        {event.time && (<p className="text-sm text-gray-600">Waktu: {event.time}</p>)}
                        {event.location && (<p className="text-sm text-gray-600">Lokasi: {event.location}</p>)}
                      </div>
                      <Badge className={event.type === 'holiday' ? 'bg-red-100 text-red-800 border-red-200' : 'bg-blue-100 text-blue-800 border-blue-200'}>
                        {event.type === 'holiday' ? 'Libur' : 'Kegiatan'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </Layout>
  );
};

export default CalendarPage;