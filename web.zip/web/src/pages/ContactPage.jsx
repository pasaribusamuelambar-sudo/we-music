import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  Send, 
  User, 
  MessageSquare,
  Building,
  Globe,
  Facebook,
  Instagram,
  Youtube,
  Linkedin
} from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const contactInfo = [
    {
      icon: MapPin,
      title: 'Alamat',
      content: 'Jl. Ahmad Yani, Batam Centre, Batam 29461, Kepulauan Riau, Indonesia',
      color: 'bg-blue-500'
    },
    {
      icon: Phone,
      title: 'Telepon',
      content: '(0778) 469858 / 469859',
      color: 'bg-green-500'
    },
    {
      icon: Mail,
      title: 'Email',
      content: 'info@polibatam.ac.id',
      color: 'bg-purple-500'
    },
    {
      icon: Clock,
      title: 'Jam Operasional',
      content: 'Senin - Jumat: 08:00 - 16:00 WIB',
      color: 'bg-orange-500'
    }
  ];

  const departments = [
    {
      name: 'Teknik Informatika',
      head: 'Dr. Ir. Suharto, M.T.',
      email: 'ti@polibatam.ac.id',
      phone: '(0778) 469858 ext. 101'
    },
    {
      name: 'Teknik Elektro',
      head: 'Prof. Dr. Bambang Wijaya, S.T., M.Kom.',
      email: 'te@polibatam.ac.id',
      phone: '(0778) 469858 ext. 102'
    },
    {
      name: 'Teknik Mesin',
      head: 'Dr. Eng. Fitri Yuli Zulkifli, S.T., M.T.',
      email: 'tm@polibatam.ac.id',
      phone: '(0778) 469858 ext. 103'
    },
    {
      name: 'Manajemen Bisnis',
      head: 'Ir. Sari Dewi Budiwati, M.Kom.',
      email: 'mb@polibatam.ac.id',
      phone: '(0778) 469858 ext. 104'
    }
  ];

  const socialMedia = [
    { name: 'Facebook', icon: Facebook, url: 'https://facebook.com/polibatam', color: 'bg-blue-600' },
    { name: 'Instagram', icon: Instagram, url: 'https://instagram.com/polibatam', color: 'bg-pink-500' },
    { name: 'YouTube', icon: Youtube, url: 'https://youtube.com/@polibatam', color: 'bg-red-500' },
    { name: 'LinkedIn', icon: Linkedin, url: 'https://linkedin.com/school/polibatam', color: 'bg-blue-700' }
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      toast({
        title: "Error",
        description: "Mohon isi semua field yang diperlukan",
        variant: "destructive",
      });
      return;
    }

    // Simulasi pengiriman pesan
    toast({
      title: "Pesan Terkirim!",
      description: "Terima kasih atas pesan Anda. Kami akan merespons dalam 1-2 hari kerja.",
    });

    // Reset form
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  };

  const handleSocialClick = (url) => {
    toast({
      title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀"
    });
  };

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-4"
        >
          <h1 className="text-4xl font-bold text-gray-900">Hubungi Kami</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Kami siap membantu Anda dengan pertanyaan seputar platform PBL dan 
            program akademik di Politeknik Negeri Batam
          </p>
        </motion.div>

        {/* Contact Info Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {contactInfo.map((info, index) => (
            <motion.div
              key={info.title}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 + index * 0.1 }}
            >
              <Card className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 ${info.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <info.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">{info.title}</h3>
                  <p className="text-sm text-gray-600">{info.content}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MessageSquare className="h-5 w-5" />
                  <span>Kirim Pesan</span>
                </CardTitle>
                <CardDescription>
                  Sampaikan pertanyaan, saran, atau masukan Anda kepada kami
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-1 block">
                        Nama Lengkap *
                      </label>
                      <Input
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="Masukkan nama lengkap"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-1 block">
                        Email *
                      </label>
                      <Input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="nama@email.com"
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">
                      Subjek *
                    </label>
                    <Input
                      name="subject"
                      value={formData.subject}
                      onChange={handleInputChange}
                      placeholder="Subjek pesan"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">
                      Pesan *
                    </label>
                    <Textarea
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Tulis pesan Anda di sini..."
                      rows={6}
                      required
                    />
                  </div>
                  
                  <Button type="submit" className="w-full">
                    <Send className="h-4 w-4 mr-2" />
                    Kirim Pesan
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* Additional Info */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-6"
          >
            {/* Departments */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Building className="h-5 w-5" />
                  <span>Kontak Program Studi</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {departments.map((dept, index) => (
                  <div key={dept.name} className="border-b border-gray-100 last:border-b-0 pb-4 last:pb-0">
                    <h4 className="font-semibold text-gray-900">{dept.name}</h4>
                    <p className="text-sm text-gray-600 mb-2">Kepala: {dept.head}</p>
                    <div className="flex flex-col space-y-1 text-sm text-gray-500">
                      <span>📧 {dept.email}</span>
                      <span>📞 {dept.phone}</span>
                      <span> 🅾 {dept.instagram}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Social Media */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Globe className="h-5 w-5" />
                  <span>Media Sosial</span>
                </CardTitle>
                <CardDescription>
                  Ikuti kami untuk update terbaru
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {socialMedia.map((social) => (
                    <Button
                      key={social.name}
                      variant="outline"
                      className="justify-start"
                      onClick={() => handleSocialClick(social.url)}
                    >
                      <social.icon className="h-4 w-4 mr-2" />
                      {social.name}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Tips */}
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-900">Tips Kontak Cepat</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-blue-800 space-y-2">
                <p>• Untuk pertanyaan teknis platform, gunakan form kontak di samping</p>
                <p>• Untuk masalah akademik, hubungi langsung program studi terkait</p>
                <p>• Untuk bantuan darurat, hubungi nomor telepon utama</p>
                <p>• Respon email biasanya dalam 1-2 hari kerja</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Map Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="h-5 w-5" />
                <span>Lokasi Kampus</span>
              </CardTitle>
              <CardDescription>
                Politeknik Negeri Batam - Batam Centre
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <MapPin className="h-12 w-12 mx-auto mb-2" />
                  <p className="font-medium">Peta Lokasi</p>
                  <p className="text-sm">Jl. Ahmad Yani, Batam Centre</p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-2"
                    onClick={() => toast({
                      title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀"
                    })}
                  >
                    Buka di Google Maps
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
};

export default ContactPage;