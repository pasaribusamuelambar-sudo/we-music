import React from 'react';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Briefcase, Eye, Gamepad2, Headphones as Headset, HeartHandshake, Video, Store, Sprout, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PortfolioPage = () => {
    const navigate = useNavigate();

    const portfolioProjects = [
        {
            title: "Pusat Game Santai",
            description: "Koleksi game web mini yang ringan dan adiktif untuk mengisi waktu luang. Termasuk game puzzle, arcade, dan strategi.",
            tags: ["Game", "React", "Canvas API"],
            icon: Gamepad2,
            bgColor: "from-purple-500 to-indigo-600"
        },
        {
            title: "Toko Top-Up Game",
            description: "Platform terintegrasi untuk top-up diamond, koin, dan item game populer seperti Mobile Legends, PUBG, dan Roblox.",
            tags: ["E-commerce", "Stripe", "API"],
            icon: Store,
            bgColor: "from-green-500 to-teal-600"
        },
        {
            title: "SoundScape - Dunia Musik Anda",
            description: "Aplikasi streaming musik mirip Spotify dengan playlist personal, radio, dan podcast. Dibangun dengan API publik Spotify.",
            tags: ["Musik", "API", "Streaming"],
            icon: Headset,
            bgColor: "from-pink-500 to-rose-600"
        },
        {
            title: "CurhatKU - Ruang Aman Anda",
            description: "Platform curhat online anonim untuk kesehatan mental, menghubungkan pengguna dengan pendengar terlatih.",
            tags: ["Kesehatan Mental", "Komunitas", "WebSockets"],
            icon: HeartHandshake,
            bgColor: "from-blue-500 to-cyan-600"
        },
        {
            title: "ConnectSphere - Panggilan Video",
            description: "Aplikasi video conference seperti Zoom dengan fitur screen sharing, chat, dan recording. Dibangun dengan WebRTC.",
            tags: ["Video Call", "WebRTC", "Real-time"],
            icon: Video,
            bgColor: "from-orange-500 to-amber-600"
        },
        {
            title: "KerjaYuk! - Bursa Kerja & Bisnis",
            description: "Marketplace untuk mencari pekerjaan, menawarkan jasa (web dev, ojek online), dan menyewa kendaraan.",
            tags: ["Marketplace", "Lowongan Kerja", "Bisnis"],
            icon: Briefcase,
            bgColor: "from-slate-600 to-gray-700"
        },
        {
            title: "EcoTrack - Jejak Karbon",
            description: "Aplikasi untuk melacak dan mengurangi jejak karbon harian pengguna dengan tips dan tantangan ramah lingkungan.",
            tags: ["Lingkungan", "Edukasi", "Data Visualisasi"],
            icon: Sprout,
            bgColor: "from-lime-500 to-emerald-600"
        },
        {
            title: "CullinaryGo - Jelajah Kuliner",
            description: "Platform review dan rekomendasi tempat makan lokal dengan peta interaktif dan galeri foto dari pengguna.",
            tags: ["Kuliner", "Review", "Komunitas"],
            icon: Store,
            bgColor: "from-red-500 to-orange-600"
        }
    ];

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.1
            }
        }
    };

    const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
            y: 0,
            opacity: 1,
            transition: {
                type: "spring",
                stiffness: 100
            }
        }
    };

    return (
        <Layout>
            <div className="space-y-8">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                >
                    <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-xl">
                        <CardHeader>
                            <div className="flex justify-between items-start">
                                <div>
                                    <CardTitle className="text-3xl font-bold">Portofolio Digital</CardTitle>
                                    <CardDescription className="text-blue-100">
                                        Koleksi proyek-proyek inovatif yang menampilkan keahlian dan kreativitas.
                                    </CardDescription>
                                </div>
                                <Button variant="secondary" onClick={() => navigate('/upload-project')}>
                                    <Plus className="w-4 h-4 mr-2" />
                                    Tambah Karya Baru
                                </Button>
                            </div>
                        </CardHeader>
                        <CardContent>
                            <p>
                                Setiap proyek di sini adalah cerminan dari dedikasi dan pembelajaran dalam kerangka Problem Based Learning (PBL).
                                Jelajahi berbagai ide yang telah diubah menjadi solusi nyata.
                            </p>
                        </CardContent>
                    </Card>
                </motion.div>

                <motion.div
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                >
                    {portfolioProjects.map((project, index) => (
                        <motion.div key={index} variants={itemVariants}>
                            <Card className="h-full flex flex-col project-card overflow-hidden">
                                <CardHeader className={`text-white bg-gradient-to-br ${project.bgColor}`}>
                                    <div className="flex items-center space-x-4">
                                        <project.icon className="w-10 h-10" />
                                        <div>
                                            <CardTitle className="text-xl">{project.title}</CardTitle>
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent className="flex-grow p-6 flex flex-col">
                                    <p className="text-gray-600 mb-4 flex-grow">{project.description}</p>
                                    <div className="flex flex-wrap gap-2 mb-6">
                                        {project.tags.map((tag, tagIndex) => (
                                            <Badge key={tagIndex} variant="secondary">{tag}</Badge>
                                        ))}
                                    </div>
                                    <Button onClick={() => navigate('/projects')} variant="outline" className="w-full mt-auto">
                                        <Eye className="w-4 h-4 mr-2" />
                                        Lihat Detail Proyek
                                    </Button>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </motion.div>
            </div>
        </Layout>
    );
};

export default PortfolioPage;