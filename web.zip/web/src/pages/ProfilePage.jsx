import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Edit, 
  Save, 
  Camera,
  Award,
  BookOpen,
  Code,
  Trophy,
  Star,
  Github,
  Linkedin,
  Instagram,
  Globe,
  Plus
} from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';

const ProfilePage = () => {
  const { user, setUser } = useAuth();
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '+62 812-3456-7890',
    address: 'Batam, Kepulauan Riau',
    bio: 'Mahasiswa Teknik Informatika yang passionate dalam pengembangan web dan mobile. Aktif dalam berbagai proyek PBL dan memiliki pengalaman dalam teknologi React, Node.js, dan Flutter.',
    skills: ['React.js', 'Node.js', 'Python', 'Flutter', 'MySQL', 'Git'],
    interests: ['Web Development', 'Mobile Development', 'UI/UX Design', 'Data Science'],
    socialMedia: {
      github: 'https://github.com/username',
      linkedin: 'https://linkedin.com/in/username',
      instagram: 'https://instagram.com/username',
      website: 'https://portfolio.com'
    }
  });
  const [avatarUrl, setAvatarUrl] = useState(user?.avatar);
  const fileInputRef = useRef(null);

  const achievements = [
    { title: 'Juara 1 Hackathon Polibatam 2023', description: 'Memenangkan kompetisi pengembangan aplikasi mobile untuk UMKM', date: '2023-11-15', type: 'competition', icon: Trophy },
    { title: 'Best PBL Project Semester 5', description: 'Proyek sistem manajemen perpustakaan terbaik', date: '2023-12-20', type: 'academic', icon: Award },
    { title: 'Sertifikat React Developer', description: 'Menyelesaikan kursus React.js dari Meta', date: '2023-09-10', type: 'certification', icon: BookOpen },
    { title: 'Kontributor Open Source', description: 'Berkontribusi pada 5+ proyek open source di GitHub', date: '2023-08-01', type: 'contribution', icon: Code }
  ];

  const projects = [
    { title: 'E-Learning Platform', description: 'Platform pembelajaran online dengan fitur video streaming dan quiz interaktif', technologies: ['React', 'Node.js', 'MongoDB'], status: 'Completed', grade: 'A', semester: 'Semester 6' },
    { title: 'Smart Parking System', description: 'Sistem parkir pintar menggunakan IoT dan computer vision', technologies: ['Python', 'OpenCV', 'Arduino'], status: 'In Progress', grade: null, semester: 'Semester 6' },
    { title: 'Mobile Banking App', description: 'Aplikasi mobile banking dengan fitur transfer dan pembayaran', technologies: ['Flutter', 'Firebase', 'Dart'], status: 'Completed', grade: 'A-', semester: 'Semester 5' }
  ];

  const handleInputChange = (field, value) => setProfileData(prev => ({ ...prev, [field]: value }));
  const handleSocialMediaChange = (platform, value) => setProfileData(prev => ({ ...prev, socialMedia: { ...prev.socialMedia, [platform]: value } }));

  const handleSave = () => {
    setIsEditing(false);
    toast({ title: "Profil Berhasil Diperbarui!", description: "Perubahan profil Anda telah disimpan." });
  };

  const handleCancel = () => setIsEditing(false);

  const handleAvatarChangeClick = () => fileInputRef.current.click();

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarUrl(reader.result);
        toast({ title: "Foto Profil Diperbarui!", description: "Foto profil Anda berhasil diubah (pratinjau)." });
      };
      reader.readAsDataURL(file);
    }
  };

  const getAchievementColor = (type) => {
    switch (type) {
      case 'competition': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'academic': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'certification': return 'bg-green-100 text-green-800 border-green-200';
      case 'contribution': return 'bg-purple-100 text-purple-800 border-purple-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'In Progress': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <Layout>
      <div className="space-y-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Profil Saya</h1>
            <p className="text-gray-600 mt-1">Kelola informasi profil dan portofolio Anda</p>
          </div>
          <div className="flex space-x-2">
            {isEditing ? (
              <>
                <Button variant="outline" onClick={handleCancel}>Batal</Button>
                <Button onClick={handleSave}><Save className="h-4 w-4 mr-2" />Simpan</Button>
              </>
            ) : (
              <Button onClick={() => setIsEditing(true)}><Edit className="h-4 w-4 mr-2" />Edit Profil</Button>
            )}
          </div>
        </motion.div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile">Profil</TabsTrigger>
            <TabsTrigger value="projects">Proyek</TabsTrigger>
            <TabsTrigger value="achievements">Prestasi</TabsTrigger>
            <TabsTrigger value="portfolio">Portofolio</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="relative inline-block mb-4">
                      <Avatar className="h-24 w-24">
                        <AvatarImage src={avatarUrl} />
                        <AvatarFallback className="text-2xl">{user?.name?.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
                      <Button size="icon" variant="outline" className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full" onClick={handleAvatarChangeClick}>
                        <Camera className="h-4 w-4" />
                      </Button>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-1">{profileData.name}</h3>
                    <p className="text-gray-600 mb-2">{user?.userType === 'mahasiswa' ? 'Mahasiswa' : 'Dosen'}</p>
                    <Badge variant="outline" className="mb-4">{user?.userType === 'mahasiswa' ? `NIM: ${user?.nim}` : `NID: ${user?.nid}`}</Badge>
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center justify-center space-x-2"><Mail className="h-4 w-4" /><span>{profileData.email}</span></div>
                      <div className="flex items-center justify-center space-x-2"><Phone className="h-4 w-4" /><span>{profileData.phone}</span></div>
                      <div className="flex items-center justify-center space-x-2"><MapPin className="h-4 w-4" /><span>{profileData.address}</span></div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }} className="lg:col-span-2 space-y-6">
                <Card>
                  <CardHeader><CardTitle>Informasi Dasar</CardTitle></CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-1 block">Nama Lengkap</label>
                        {isEditing ? <Input value={profileData.name} onChange={(e) => handleInputChange('name', e.target.value)} /> : <p className="text-gray-900">{profileData.name}</p>}
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-1 block">Email</label>
                        {isEditing ? <Input type="email" value={profileData.email} onChange={(e) => handleInputChange('email', e.target.value)} /> : <p className="text-gray-900">{profileData.email}</p>}
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-1 block">Nomor Telepon</label>
                        {isEditing ? <Input value={profileData.phone} onChange={(e) => handleInputChange('phone', e.target.value)} /> : <p className="text-gray-900">{profileData.phone}</p>}
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-1 block">Alamat</label>
                        {isEditing ? <Input value={profileData.address} onChange={(e) => handleInputChange('address', e.target.value)} /> : <p className="text-gray-900">{profileData.address}</p>}
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-1 block">Bio</label>
                      {isEditing ? <Textarea value={profileData.bio} onChange={(e) => handleInputChange('bio', e.target.value)} rows={4} /> : <p className="text-gray-900">{profileData.bio}</p>}
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader><CardTitle>Keahlian & Minat</CardTitle></CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-2 block">Keahlian Teknis</label>
                      <div className="flex flex-wrap gap-2">{profileData.skills.map((skill, index) => (<Badge key={index} variant="secondary">{skill}</Badge>))}</div>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-2 block">Minat</label>
                      <div className="flex flex-wrap gap-2">{profileData.interests.map((interest, index) => (<Badge key={index} variant="outline">{interest}</Badge>))}</div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader><CardTitle>Media Sosial</CardTitle></CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-1 block"><Github className="h-4 w-4 inline mr-1" />GitHub</label>
                        {isEditing ? <Input value={profileData.socialMedia.github} onChange={(e) => handleSocialMediaChange('github', e.target.value)} /> : <p className="text-gray-900">{profileData.socialMedia.github}</p>}
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-1 block"><Linkedin className="h-4 w-4 inline mr-1" />LinkedIn</label>
                        {isEditing ? <Input value={profileData.socialMedia.linkedin} onChange={(e) => handleSocialMediaChange('linkedin', e.target.value)} /> : <p className="text-gray-900">{profileData.socialMedia.linkedin}</p>}
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-1 block"><Instagram className="h-4 w-4 inline mr-1" />Instagram</label>
                        {isEditing ? <Input value={profileData.socialMedia.instagram} onChange={(e) => handleSocialMediaChange('instagram', e.target.value)} /> : <p className="text-gray-900">{profileData.socialMedia.instagram}</p>}
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-1 block"><Globe className="h-4 w-4 inline mr-1" />Website</label>
                        {isEditing ? <Input value={profileData.socialMedia.website} onChange={(e) => handleSocialMediaChange('website', e.target.value)} /> : <p className="text-gray-900">{profileData.socialMedia.website}</p>}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </TabsContent>

          <TabsContent value="projects" className="space-y-6">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <Card>
                <CardHeader><CardTitle>Proyek PBL Saya</CardTitle><CardDescription>Daftar proyek Problem Based Learning yang telah dan sedang dikerjakan</CardDescription></CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {projects.map((project, index) => (
                      <motion.div key={index} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + index * 0.1 }} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-semibold text-gray-900">{project.title}</h4>
                          <div className="flex space-x-2">
                            <Badge className={getStatusColor(project.status)}>{project.status}</Badge>
                            {project.grade && <Badge variant="outline">Nilai: {project.grade}</Badge>}
                          </div>
                        </div>
                        <p className="text-gray-600 mb-3">{project.description}</p>
                        <div className="flex flex-wrap gap-2 mb-3">{project.technologies.map((tech, techIndex) => (<Badge key={techIndex} variant="secondary" className="text-xs">{tech}</Badge>))}</div>
                        <div className="flex justify-between items-center text-sm text-gray-500">
                          <span>{project.semester}</span>
                          <Button variant="outline" size="sm" onClick={() => navigate('/projects')}>Lihat Detail</Button>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="achievements" className="space-y-6">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <Card>
                <CardHeader><CardTitle>Prestasi & Pencapaian</CardTitle><CardDescription>Penghargaan, sertifikat, dan pencapaian lainnya</CardDescription></CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {achievements.map((achievement, index) => {
                      const IconComponent = achievement.icon;
                      return (
                        <motion.div key={index} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2 + index * 0.1 }} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                          <div className="flex items-start space-x-4">
                            <div className="p-2 bg-blue-100 rounded-lg"><IconComponent className="h-6 w-6 text-blue-600" /></div>
                            <div className="flex-1">
                              <div className="flex justify-between items-start mb-2">
                                <h4 className="font-semibold text-gray-900">{achievement.title}</h4>
                                <Badge className={getAchievementColor(achievement.type)}>{achievement.type}</Badge>
                              </div>
                              <p className="text-gray-600 mb-2">{achievement.description}</p>
                              <div className="flex items-center space-x-2 text-sm text-gray-500"><Calendar className="h-4 w-4" /><span>{new Date(achievement.date).toLocaleDateString('id-ID')}</span></div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="portfolio" className="space-y-6">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <Card>
                <CardHeader><CardTitle>Portofolio Digital</CardTitle><CardDescription>Showcase karya dan proyek terbaik Anda</CardDescription></CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[1, 2, 3, 4, 5, 6].map((item) => (
                      <motion.div key={item} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2 + item * 0.1 }} className="border rounded-lg overflow-hidden hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate('/portfolio')}>
                        <div className="h-32 bg-gradient-to-br from-blue-400 to-purple-500"></div>
                        <div className="p-4">
                          <h4 className="font-semibold text-gray-900 mb-1">Project {item}</h4>
                          <p className="text-sm text-gray-600 mb-2">Deskripsi singkat proyek</p>
                          <div className="flex justify-between items-center">
                            <Badge variant="outline" className="text-xs">Web App</Badge>
                            <div className="flex items-center space-x-1 text-yellow-500"><Star className="h-3 w-3 fill-current" /><span className="text-xs">4.8</span></div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  <div className="text-center mt-6">
                    <Button variant="outline" onClick={() => navigate('/upload-project')}><Plus className="h-4 w-4 mr-2" />Tambah Karya Baru</Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default ProfilePage;