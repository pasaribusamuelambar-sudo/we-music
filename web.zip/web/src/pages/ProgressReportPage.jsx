import React from 'react';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, FileText, CheckCircle, Clock, AlertCircle, Download } from 'lucide-react';

const ProgressReportPage = () => {
    const overallProgress = {
        semester: "Semester 6",
        completion: 75,
        projects: [
            { id: 1, title: "Sistem Manajemen Perpustakaan", status: "Selesai", progress: 100, grade: "A" },
            { id: 2, title: "E-Commerce Platform UMKM", status: "Dalam Progress", progress: 60, grade: null },
            { id: 3, title: "Aplikasi Mobile Learning", status: "Perencanaan", progress: 15, grade: null },
        ],
        summary: {
            completed: 1,
            in_progress: 1,
            planned: 1,
            total: 3,
            average_grade: "A",
        }
    };

    const getStatusInfo = (status) => {
        switch (status) {
            case 'Selesai':
                return { icon: CheckCircle, color: 'text-green-500', badge: 'bg-green-100 text-green-800' };
            case 'Dalam Progress':
                return { icon: Clock, color: 'text-blue-500', badge: 'bg-blue-100 text-blue-800' };
            case 'Perencanaan':
                return { icon: AlertCircle, color: 'text-yellow-500', badge: 'bg-yellow-100 text-yellow-800' };
            default:
                return { icon: FileText, color: 'text-gray-500', badge: 'bg-gray-100 text-gray-800' };
        }
    };

    return (
        <Layout>
            <div className="space-y-8">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <div className="flex justify-between items-center mb-6">
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900">Laporan Progress</h1>
                            <p className="text-gray-600 mt-1">
                                Ringkasan kemajuan proyek PBL Anda untuk {overallProgress.semester}.
                            </p>
                        </div>
                        <Button variant="outline">
                            <Download className="h-4 w-4 mr-2" />
                            Unduh Laporan (PDF)
                        </Button>
                    </div>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0, transition: { delay: 0.1 } }}
                >
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center"><TrendingUp className="h-6 w-6 mr-3 text-blue-600"/>Kemajuan Keseluruhan</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <div className="flex justify-between mb-1">
                                    <span className="text-base font-medium text-blue-700">Progress Semester</span>
                                    <span className="text-sm font-medium text-blue-700">{overallProgress.completion}%</span>
                                </div>
                                <Progress value={overallProgress.completion} className="w-full" />
                            </div>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center pt-4">
                                <div>
                                    <p className="text-2xl font-bold">{overallProgress.summary.total}</p>
                                    <p className="text-sm text-gray-500">Total Proyek</p>
                                </div>
                                <div>
                                    <p className="text-2xl font-bold text-green-600">{overallProgress.summary.completed}</p>
                                    <p className="text-sm text-gray-500">Selesai</p>
                                </div>
                                <div>
                                    <p className="text-2xl font-bold text-blue-600">{overallProgress.summary.in_progress}</p>
                                    <p className="text-sm text-gray-500">Dalam Progress</p>
                                </div>
                                <div>
                                    <p className="text-2xl font-bold text-gray-600">{overallProgress.summary.average_grade}</p>
                                    <p className="text-sm text-gray-500">Rata-rata Nilai</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0, transition: { delay: 0.2 } }}
                >
                    <h2 className="text-2xl font-bold text-gray-900 mb-4">Detail Proyek</h2>
                    <div className="space-y-6">
                        {overallProgress.projects.map((project, index) => {
                            const statusInfo = getStatusInfo(project.status);
                            const Icon = statusInfo.icon;
                            return (
                                <motion.div
                                    key={project.id}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0, transition: { delay: 0.3 + index * 0.1 } }}
                                >
                                    <Card className="hover:shadow-md transition-shadow">
                                        <CardHeader>
                                            <div className="flex justify-between items-start">
                                                <CardTitle>{project.title}</CardTitle>
                                                <div className="flex items-center space-x-2">
                                                    {project.grade && <Badge variant="default">Nilai: {project.grade}</Badge>}
                                                    <Badge className={statusInfo.badge}>{project.status}</Badge>
                                                </div>
                                            </div>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="flex items-center space-x-4">
                                                <Icon className={`h-6 w-6 ${statusInfo.color}`} />
                                                <div className="flex-grow">
                                                    <Progress value={project.progress} />
                                                </div>
                                                <span className="w-12 text-right font-medium">{project.progress}%</span>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            );
                        })}
                    </div>
                </motion.div>
            </div>
        </Layout>
    );
};

export default ProgressReportPage;