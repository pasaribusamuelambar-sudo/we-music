import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { Search, Filter, Plus, Eye, Edit, Trash2, Github, ExternalLink, FolderOpen } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const ProjectsPage = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  const projects = [
    {
      id: 1,
      title: 'Sistem Manajemen Perpustakaan Digital',
      description: 'Aplikasi web untuk mengelola koleksi buku, peminjaman, dan pengembalian dengan fitur notifikasi otomatis dan laporan statistik.',
      status: 'Selesai',
      semester: 'Semester 6',
      mataKuliah: 'Pemrograman Web Lanjut',
      teknologi: ['React', 'Node.js', 'MySQL', 'Express'],
      tanggalMulai: '2024-02-01',
      tanggalSelesai: '2024-05-15',
      anggotaTim: ['Ahmad Rizki', 'Siti Nurhaliza', 'Budi Santoso'],
      dosen: 'Dr. Ir. Suharto, M.T.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=200&fit=crop',
      githubUrl: 'https://github.com/user/library-management',
      demoUrl: 'https://library-demo.polibatam.ac.id',
      nilai: 'A',
    },
    {
      id: 2,
      title: 'E-Commerce Platform UMKM Batam',
      description: 'Platform marketplace untuk mendukung UMKM di Batam dengan fitur pembayaran digital, manajemen inventory, dan sistem rating.',
      status: 'Dalam Progress',
      semester: 'Semester 6',
      mataKuliah: 'Proyek Perangkat Lunak',
      teknologi: ['Vue.js', 'Laravel', 'PostgreSQL', 'Redis'],
      tanggalMulai: '2024-03-01',
      tanggalSelesai: '2024-06-30',
      anggotaTim: ['Dewi Sartika', 'Andi Pratama', 'Lisa Permata'],
      dosen: 'Prof. Dr. Bambang Wijaya, S.T., M.Kom.',
      image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&h=200&fit=crop',
      githubUrl: 'https://github.com/user/umkm-ecommerce',
      demoUrl: null,
      nilai: null,
    },
    {
      id: 3,
      title: 'IoT Smart Home Monitoring System',
      description: 'Sistem monitoring rumah pintar menggunakan sensor IoT untuk mengontrol suhu, kelembaban, keamanan, dan konsumsi energi.',
      status: 'Perencanaan',
      semester: 'Semester 7',
      mataKuliah: 'Internet of Things',
      teknologi: ['Arduino', 'Raspberry Pi', 'Python', 'MQTT', 'React Native'],
      tanggalMulai: '2024-08-01',
      tanggalSelesai: '2024-12-15',
      anggotaTim: ['Reza Firmansyah', 'Maya Sari', 'Doni Kurniawan'],
      dosen: 'Dr. Eng. Fitri Yuli Zulkifli, S.T., M.T.',
      image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=200&fit=crop',
      githubUrl: null,
      demoUrl: null,
      nilai: null,
    },
    {
      id: 4,
      title: 'Aplikasi Mobile Learning Bahasa Inggris',
      description: 'Aplikasi pembelajaran bahasa Inggris interaktif dengan fitur speech recognition, quiz adaptif, dan progress tracking.',
      status: 'Selesai',
      semester: 'Semester 5',
      mataKuliah: 'Pemrograman Mobile',
      teknologi: ['Flutter', 'Firebase', 'TensorFlow Lite', 'Google Cloud'],
      tanggalMulai: '2023-09-01',
      tanggalSelesai: '2023-12-20',
      anggotaTim: ['Indira Putri', 'Fajar Nugroho'],
      dosen: 'Ir. Sari Dewi Budiwati, M.Kom.',
      image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=400&h=200&fit=crop',
      githubUrl: 'https://github.com/user/english-learning-app',
      demoUrl: 'https://play.google.com/store/apps/details?id=com.polibatam.englishapp',
      nilai: 'A-',
    },
  ];

  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.teknologi.some(tech => tech.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesFilter = filterStatus === 'all' || project.status.toLowerCase().includes(filterStatus.toLowerCase());
    
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'Selesai':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Dalam Progress':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Perencanaan':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleAction = (action, project = null) => {
    toast({
      title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀"
    });
  };

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Proyek PBL</h1>
            <p className="text-gray-600 mt-1">
              Kelola dan pantau semua proyek Problem Based Learning Anda
            </p>
          </div>
          <Button 
            onClick={() => handleAction('create')}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Tambah Proyek
          </Button>
        </motion.div>

        {/* Search and Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex flex-col sm:flex-row gap-4"
        >
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Cari proyek, teknologi, atau deskripsi..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <Button
              variant={filterStatus === 'all' ? 'default' : 'outline'}
              onClick={() => setFilterStatus('all')}
              size="sm"
            >
              Semua
            </Button>
            <Button
              variant={filterStatus === 'selesai' ? 'default' : 'outline'}
              onClick={() => setFilterStatus('selesai')}
              size="sm"
            >
              Selesai
            </Button>
            <Button
              variant={filterStatus === 'progress' ? 'default' : 'outline'}
              onClick={() => setFilterStatus('progress')}
              size="sm"
            >
              Progress
            </Button>
            <Button
              variant={filterStatus === 'perencanaan' ? 'default' : 'outline'}
              onClick={() => setFilterStatus('perencanaan')}
              size="sm"
            >
              Perencanaan
            </Button>
          </div>
        </motion.div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1 }}
            >
              <Card className="project-card h-full">
                <div className="relative">
                  <img  
                    className="w-full h-48 object-cover rounded-t-lg"
                    alt={`Gambar proyek ${project.title}`}
                   src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
                  <div className="absolute top-4 right-4">
                    <Badge className={getStatusColor(project.status)}>
                      {project.status}
                    </Badge>
                  </div>
                  {project.nilai && (
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                        Nilai: {project.nilai}
                      </Badge>
                    </div>
                  )}
                </div>
                
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-2">{project.title}</CardTitle>
                      <div className="flex flex-wrap gap-2 mb-2">
                        <Badge variant="outline" className="text-xs">
                          {project.semester}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {project.mataKuliah}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <CardDescription className="text-sm">
                    {project.description}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {/* Teknologi */}
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-2">Teknologi:</p>
                    <div className="flex flex-wrap gap-1">
                      {project.teknologi.map((tech) => (
                        <Badge key={tech} variant="secondary" className="text-xs">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  {/* Tim dan Dosen */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="font-medium text-gray-700">Tim:</p>
                      <p className="text-gray-600">{project.anggotaTim.join(', ')}</p>
                    </div>
                    <div>
                      <p className="font-medium text-gray-700">Dosen Pembimbing:</p>
                      <p className="text-gray-600">{project.dosen}</p>
                    </div>
                  </div>
                  
                  {/* Timeline */}
                  <div className="text-sm">
                    <p className="font-medium text-gray-700">Timeline:</p>
                    <p className="text-gray-600">
                      {new Date(project.tanggalMulai).toLocaleDateString('id-ID')} - {new Date(project.tanggalSelesai).toLocaleDateString('id-ID')}
                    </p>
                  </div>
                  
                  {/* Actions */}
                  <div className="flex flex-wrap gap-2 pt-4 border-t">
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleAction('view', project)}
                    >
                      <Eye className="h-3 w-3 mr-1" />
                      Lihat
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleAction('edit', project)}
                    >
                      <Edit className="h-3 w-3 mr-1" />
                      Edit
                    </Button>
                    {project.githubUrl && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleAction('github', project)}
                      >
                        <Github className="h-3 w-3 mr-1" />
                        GitHub
                      </Button>
                    )}
                    {project.demoUrl && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleAction('demo', project)}
                      >
                        <ExternalLink className="h-3 w-3 mr-1" />
                        Demo
                      </Button>
                    )}
                    {user?.userType === 'mahasiswa' && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        className="text-red-600 hover:text-red-700"
                        onClick={() => handleAction('delete', project)}
                      >
                        <Trash2 className="h-3 w-3 mr-1" />
                        Hapus
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {filteredProjects.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <div className="text-gray-400 mb-4">
              <FolderOpen className="h-16 w-16 mx-auto" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Tidak ada proyek ditemukan</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm || filterStatus !== 'all' 
                ? 'Coba ubah filter atau kata kunci pencarian Anda'
                : 'Mulai dengan membuat proyek PBL pertama Anda'
              }
            </p>
            {!searchTerm && filterStatus === 'all' && (
              <Button onClick={() => handleAction('create')}>
                <Plus className="h-4 w-4 mr-2" />
                Buat Proyek Pertama
              </Button>
            )}
          </motion.div>
        )}
      </div>
    </Layout>
  );
};

export default ProjectsPage;