import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Search, SlidersHorizontal, User, Folder, MessageCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';

const SearchStudentsPage = () => {
    const { toast } = useToast();
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');

    const students = [
        { id: 1, name: "Ahmad Rizki", nim: "3312301001", prodi: "Teknik Informatika", semester: 6, projects: 5, avatar: "Cool guy doing code" },
        { id: 2, name: "Siti Nurhaliza", nim: "3312301002", prodi: "Teknik Informatika", semester: 6, projects: 4, avatar: "Girl with glasses in library" },
        { id: 3, name: "Budi Santoso", nim: "3322301003", prodi: "Teknik Mesin", semester: 4, projects: 3, avatar: "Man working with machinery" },
        { id: 4, name: "Dewi Lestari", nim: "3332301004", prodi: "Teknik Elektro", semester: 8, projects: 7, avatar: "Woman with electronic circuit" },
        { id: 5, name: "Andi Pratama", nim: "3412301005", prodi: "Manajemen Bisnis", semester: 2, projects: 1, avatar: "Young man in a suit" },
        { id: 6, name: "Reza Firmansyah", nim: "3312301006", prodi: "Teknik Informatika", semester: 6, projects: 6, avatar: "Man presenting in front of whiteboard" },
    ];

    const filteredStudents = students.filter(student =>
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.nim.includes(searchTerm) ||
        student.prodi.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const handleAction = (action) => {
        if (action === 'profile') {
            navigate('/profile');
        } else if (action === 'portfolio') {
            navigate('/portfolio');
        } else {
            toast({
                title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀"
            });
        }
    };

    return (
        <Layout>
            <div className="space-y-8">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-2xl font-bold">Cari Mahasiswa</CardTitle>
                            <CardDescription>
                                Temukan mahasiswa berdasarkan nama, NIM, atau program studi untuk kolaborasi atau penilaian.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="flex gap-4">
                                <div className="relative flex-grow">
                                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                                    <Input
                                        placeholder="Ketik nama, NIM, atau program studi..."
                                        className="pl-10"
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                </div>
                                <Button variant="outline" onClick={() => handleAction('filter')}>
                                    <SlidersHorizontal className="h-4 w-4 mr-2" />
                                    Filter
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>

                <motion.div
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1, transition: { delay: 0.2, staggerChildren: 0.1 } }}
                >
                    {filteredStudents.map((student, index) => (
                        <motion.div
                            key={student.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                        >
                            <Card className="hover:shadow-lg transition-shadow">
                                <CardContent className="p-6">
                                    <div className="flex items-center space-x-4 mb-4">
                                        <Avatar className="h-16 w-16">
                                            <img alt={student.avatar} class="h-16 w-16 rounded-full object-cover" src="https://images.unsplash.com/photo-1610208322526-80d5930cc725" />
                                            <AvatarFallback>{student.name.charAt(0)}</AvatarFallback>
                                        </Avatar>
                                        <div>
                                            <h3 className="text-lg font-semibold">{student.name}</h3>
                                            <p className="text-sm text-gray-500">{student.nim}</p>
                                        </div>
                                    </div>
                                    <div className="space-y-2 text-sm mb-4">
                                        <p><strong>Prodi:</strong> {student.prodi}</p>
                                        <p><strong>Semester:</strong> {student.semester}</p>
                                        <Badge variant="secondary">{student.projects} Proyek</Badge>
                                    </div>
                                    <div className="flex gap-2">
                                        <Button onClick={() => handleAction('profile')} size="sm" variant="outline" className="flex-1">
                                            <User className="h-4 w-4 mr-2" /> Profil
                                        </Button>
                                        <Button onClick={() => handleAction('portfolio')} size="sm" variant="outline" className="flex-1">
                                            <Folder className="h-4 w-4 mr-2" /> Portofolio
                                        </Button>
                                        <Button onClick={() => handleAction('message')} size="sm" className="flex-1">
                                            <MessageCircle className="h-4 w-4 mr-2" /> Kirim Pesan
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </motion.div>

                {filteredStudents.length === 0 && (
                     <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-12 text-gray-500">
                        <Search className="h-16 w-16 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-800">Mahasiswa tidak ditemukan</h3>
                        <p>Coba gunakan kata kunci pencarian yang berbeda.</p>
                    </motion.div>
                )}
            </div>
        </Layout>
    );
};

export default SearchStudentsPage;