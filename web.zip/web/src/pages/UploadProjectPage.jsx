import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Upload, Plus, Trash2, Link, FileText, Users, GraduationCap } from 'lucide-react';

// Komponen untuk preview file yang diunggah
const FilePreview = ({ files }) => {
    if (!files || files.length === 0) return null;
    return (
        <div className="mt-2 grid grid-cols-2 gap-2">
            {Array.from(files).map((file, idx) => (
                <div key={idx} className="p-2 rounded border bg-gray-100 flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    <span className="text-xs truncate">{file.name}</span>
                </div>
            ))}
        </div>
    );
};

const UploadProjectPage = () => {
    const { toast } = useToast();
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [technologies, setTechnologies] = useState(['']);
    const [githubUrl, setGithubUrl] = useState('');
    const [demoUrl, setDemoUrl] = useState('');
    const [files, setFiles] = useState([]);
    const [course, setCourse] = useState('');
    const [semester, setSemester] = useState('');

    const handleTechChange = (index, value) => {
        const newTech = [...technologies];
        newTech[index] = value;
        setTechnologies(newTech);
    };

    const addTechField = () => {
        setTechnologies([...technologies, '']);
    };

    const removeTechField = (index) => {
        const newTech = technologies.filter((_, i) => i !== index);
        setTechnologies(newTech);
    };

    const handleFileChange = (e) => {
        setFiles(e.target.files);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Validasi
        if (!title || !description) {
            toast({
                title: "Error",
                description: "Judul dan deskripsi proyek harus diisi.",
                variant: "destructive",
            });
            return;
        }

        console.log({
            title,
            description,
            technologies: technologies.filter(t => t),
            githubUrl,
            demoUrl,
            course,
            semester,
            files
        });

        toast({
            title: "Proyek Berhasil Diunggah!",
            description: `${title} telah ditambahkan ke portofolio Anda.`,
        });

        // Reset form
        setTitle('');
        setDescription('');
        setTechnologies(['']);
        setGithubUrl('');
        setDemoUrl('');
        setFiles([]);
        setCourse('');
        setSemester('');
    };

    return (
        <Layout>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="max-w-4xl mx-auto"
            >
                <Card>
                    <CardHeader>
                        <div className="flex items-center space-x-3">
                            <Upload className="h-6 w-6 text-blue-600" />
                            <CardTitle className="text-2xl font-bold">Upload Proyek Baru</CardTitle>
                        </div>
                        <CardDescription>
                            Dokumentasikan dan pamerkan hasil kerja keras Anda dalam proyek PBL.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-8">
                            <div className="space-y-2">
                                <Label htmlFor="title" className="flex items-center"><FileText className="h-4 w-4 mr-2" />Judul Proyek</Label>
                                <Input id="title" placeholder="cth. Sistem Manajemen Perpustakaan" value={title} onChange={(e) => setTitle(e.target.value)} required />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="description" className="flex items-center"><FileText className="h-4 w-4 mr-2" />Deskripsi Proyek</Label>
                                <Textarea id="description" placeholder="Jelaskan tujuan, fitur, dan proses pengembangan proyek Anda." rows={5} value={description} onChange={(e) => setDescription(e.target.value)} required />
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <Label className="flex items-center"><Users className="h-4 w-4 mr-2" />Mata Kuliah</Label>
                                    <Input placeholder="cth. Pemrograman Web Lanjut" value={course} onChange={e => setCourse(e.target.value)} />
                                </div>
                                <div className="space-y-2">
                                    <Label className="flex items-center"><GraduationCap className="h-4 w-4 mr-2" />Semester</Label>
                                    <Input type="number" placeholder="cth. 6" value={semester} onChange={e => setSemester(e.target.value)} />
                                </div>
                            </div>

                            <div className="space-y-4">
                                <Label className="flex items-center"><Users className="h-4 w-4 mr-2" />Teknologi yang Digunakan</Label>
                                {technologies.map((tech, index) => (
                                    <div key={index} className="flex items-center gap-2">
                                        <Input placeholder="cth. React.js" value={tech} onChange={(e) => handleTechChange(index, e.target.value)} />
                                        <Button type="button" variant="destructive" size="icon" onClick={() => removeTechField(index)} disabled={technologies.length === 1}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                ))}
                                <Button type="button" variant="outline" size="sm" onClick={addTechField}>
                                    <Plus className="h-4 w-4 mr-2" /> Tambah Teknologi
                                </Button>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <Label htmlFor="githubUrl" className="flex items-center"><Link className="h-4 w-4 mr-2" />URL Repositori GitHub</Label>
                                    <Input id="githubUrl" placeholder="https://github.com/..." value={githubUrl} onChange={(e) => setGithubUrl(e.target.value)} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="demoUrl" className="flex items-center"><Link className="h-4 w-4 mr-2" />URL Demo Proyek</Label>
                                    <Input id="demoUrl" placeholder="https://proyek-anda.com" value={demoUrl} onChange={(e) => setDemoUrl(e.target.value)} />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="file-upload">Upload File (Gambar, Video, Dokumen)</Label>
                                <div className="flex items-center justify-center w-full">
                                    <label htmlFor="file-upload" className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                            <Upload className="w-8 h-8 mb-2 text-gray-500" />
                                            <p className="mb-2 text-sm text-gray-500"><span className="font-semibold">Klik untuk mengunggah</span> atau seret file</p>
                                            <p className="text-xs text-gray-500">PNG, JPG, MP4, PDF (MAX. 10MB)</p>
                                        </div>
                                        <Input id="file-upload" type="file" className="hidden" multiple onChange={handleFileChange} />
                                    </label>
                                </div>
                                <FilePreview files={files} />
                            </div>

                            <div className="flex justify-end pt-4">
                                <Button type="submit" size="lg">
                                    <Upload className="h-4 w-4 mr-2" /> Submit Proyek
                                </Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>
            </motion.div>
        </Layout>
    );
};

export default UploadProjectPage;