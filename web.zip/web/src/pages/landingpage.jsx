import React from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge'; // Import Badge component
import { ArrowRight, BookOpen, Users, Award, Code, Gamepad2, Music, Briefcase } from 'lucide-react';

const LandingPage = () => {
    const navigate = useNavigate();

    const features = [
        {
            icon: BookOpen,
            title: "Portofolio Digital",
            description: "Dokumentasikan setiap proyek PBL Anda dalam portofolio digital yang profesional dan mudah dibagikan.",
        },
        {
            icon: Users,
            title: "Kolaborasi Tim",
            description: "Bekerja sama dengan tim, dapatkan masukan dari dosen, dan lacak kemajuan bersama.",
        },
        {
            icon: Award,
            title: "Pamerkan Prestasi",
            description: "Tampilkan proyek terbaik dan pencapaian Anda kepada publik dan calon pemberi kerja.",
        },
    ];

    const projectExamples = [
        { icon: Gamepad2, title: "Komunitas Game" },
        { icon: Music, title: "Platform Musik" },
        { icon: Briefcase, title: "Bursa Lowongan Kerja" },
        { icon: Code, title: "Proyek IoT & Web" },
    ];

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 text-gray-800">
            {/* Header */}
            <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg shadow-sm">
                <div className="container mx-auto px-6 py-4 flex justify-between items-center">
                    <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                            <span className="text-white font-bold text-sm">PBL</span>
                        </div>
                        <span className="text-xl font-bold text-gray-900">Portofolio PBL</span>
                    </div>
                    <nav className="hidden md:flex items-center space-x-6">
                        <a href="#features" className="text-gray-600 hover:text-blue-600 transition">Fitur</a>
                        <a href="#projects" className="text-gray-600 hover:text-blue-600 transition">Proyek</a>
                        <a href="#about" className="text-gray-600 hover:text-blue-600 transition">Tentang</a>
                    </nav>
                    <Button onClick={() => navigate('/login')}>
                        Masuk / Daftar
                        <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                </div>
            </header>

            {/* Hero Section */}
            <main className="container mx-auto px-6 py-16 md:py-24">
                <motion.section
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                    className="text-center"
                >
                    <Badge variant="outline" className="mb-4 text-blue-600 border-blue-200 bg-blue-50">
                        Politeknik Negeri Batam
                    </Badge>
                    <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 mb-4 leading-tight">
                        Wujudkan Ide, Bangun Portofolio.
                    </h1>
                    <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto mb-8">
                        Platform digital untuk mahasiswa Politeknik Negeri Batam mendokumentasikan, berkolaborasi, dan memamerkan proyek-proyek Problem Based Learning (PBL) mereka.
                    </p>
                    <div className="flex justify-center gap-4">
                        <Button size="lg" onClick={() => navigate('/login')}>
                            Mulai Sekarang
                        </Button>
                        <Button size="lg" variant="outline" onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}>
                            Pelajari Lebih Lanjut
                        </Button>
                    </div>
                </motion.section>

                {/* Features Section */}
                <section id="features" className="py-24">
                    <div className="text-center mb-12">
                        <h2 className="text-3xl font-bold text-gray-900">Fitur Unggulan</h2>
                        <p className="text-gray-600 mt-2">Semua yang Anda butuhkan untuk sukses dalam PBL.</p>
                    </div>
                    <div className="grid md:grid-cols-3 gap-8">
                        {features.map((feature, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.5, delay: index * 0.1 }}
                            >
                                <Card className="text-center p-8 h-full hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
                                    <div className="inline-block p-4 bg-blue-100 text-blue-600 rounded-full mb-4">
                                        <feature.icon className="w-8 h-8" />
                                    </div>
                                    <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                                    <p className="text-gray-600">{feature.description}</p>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                </section>

                {/* Project Examples Section */}
                <section id="projects" className="py-24 bg-white rounded-2xl">
                    <div className="text-center mb-12">
                        <h2 className="text-3xl font-bold text-gray-900">Dari Ide Menjadi Karya Nyata</h2>
                        <p className="text-gray-600 mt-2">Lihat contoh proyek-proyek inovatif yang lahir dari PBL.</p>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                        {projectExamples.map((proj, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, scale: 0.9 }}
                                whileInView={{ opacity: 1, scale: 1 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.5, delay: index * 0.1 }}
                            >
                                <Card className="p-6 flex flex-col items-center justify-center h-full bg-gray-50 hover:bg-gray-100 transition">
                                    <proj.icon className="w-10 h-10 text-blue-600 mb-3" />
                                    <h4 className="font-semibold text-center">{proj.title}</h4>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                    <div className="text-center mt-12">
                        <Button variant="link" onClick={() => navigate('/login')}>
                            Jelajahi lebih banyak proyek <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                    </div>
                </section>

                {/* Call to Action Section */}
                <section id="about" className="py-24">
                    <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-center text-white">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.7 }}
                        >
                            <h2 className="text-3xl font-bold mb-4">Siap Membangun Masa Depan Anda?</h2>
                            <p className="max-w-2xl mx-auto mb-8">
                                Bergabunglah dengan ratusan mahasiswa dan dosen Polibatam lainnya. Mulai bangun portofolio digital Anda hari ini dan tunjukkan potensi terbaik Anda kepada dunia.
                            </p>
                            <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100" onClick={() => navigate('/login')}>
                                Daftar Gratis
                            </Button>
                        </motion.div>
                    </div>
                </section>
            </main>

            {/* Footer */}
            <footer className="border-t">
                <div className="container mx-auto px-6 py-8 text-center text-gray-600">
                    <p>&copy; {new Date().getFullYear()} Portofolio PBL - Politeknik Negeri Batam. Semua Hak Cipta Dilindungi.</p>
                </div>
            </footer>
        </div>
    );
};

export default LandingPage;