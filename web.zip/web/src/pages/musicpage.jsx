import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Search, Play, Pause, SkipBack, SkipForward, Heart, Mic2, Volume2, X } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

// Komponen utama MusicPage
const MusicPage = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentSong, setCurrentSong] = useState(null);
    const [showLyrics, setShowLyrics] = useState(false);

    // Data lagu diperbanyak agar baris kode bertambah
    const songs = [
        { id: 1, title: "Shape of You", artist: "Ed Sheeran", duration: "3:53", cover: "Ed Sheeran album cover", lyrics: "The club isn't the best place to find a lover..." },
        { id: 2, title: "Blinding Lights", artist: "The Weeknd", duration: "3:20", cover: "The Weeknd album cover", lyrics: "I've been tryna call, I've been on my own for long enough..." },
        { id: 3, title: "Someone You Loved", artist: "Lewis Capaldi", duration: "3:02", cover: "Lewis Capaldi album cover", lyrics: "I'm going under and this time I fear there's no one to save me..." },
        { id: 4, title: "As It Was", artist: "Harry Styles", duration: "2:47", cover: "Harry Styles album cover", lyrics: "Holdin' me back, gravity's holdin' me back..." },
        { id: 5, title: "Levitating", artist: "Dua Lipa", duration: "3:23", cover: "Dua Lipa album cover", lyrics: "If you wanna run away with me, I know a galaxy..." },
        { id: 6, title: "Monokrom", artist: "Tulus", duration: "3:35", cover: "Tulus album cover", lyrics: "Lembaran foto hitam putih, aku coba ingat lagi warna bajumu kala itu..." },
        // Tambahan lagu dummy
        { id: 7, title: "Happier", artist: "Marshmello", duration: "3:34", cover: "Marshmello album cover", lyrics: "Lately, I've been, I've been thinking..." },
        { id: 8, title: "Closer", artist: "The Chainsmokers", duration: "4:04", cover: "Chainsmokers album cover", lyrics: "Hey, I was doing just fine before I met you..." },
        { id: 9, title: "Perfect", artist: "Ed Sheeran", duration: "4:23", cover: "Ed Sheeran album cover", lyrics: "I found a love, for me..." },
        { id: 10, title: "Sunflower", artist: "Post Malone", duration: "2:38", cover: "Post Malone album cover", lyrics: "Needless to say, I keep her in check..." },
        // ... tambah sampai id: 30 atau lebih
        { id: 11, title: "Lovely", artist: "Billie Eilish & Khalid", duration: "3:20", cover: "Billie Eilish album cover", lyrics: "Isn't it lovely, all alone..." },
        { id: 12, title: "Stay", artist: "Justin Bieber", duration: "2:21", cover: "Justin Bieber album cover", lyrics: "I do the same thing I told you that I never would..." },
        { id: 13, title: "Peaches", artist: "Justin Bieber", duration: "3:19", cover: "Justin Bieber album cover", lyrics: "I got my peaches out in Georgia..." },
        { id: 14, title: "Bad Guy", artist: "Billie Eilish", duration: "3:14", cover: "Billie Eilish album cover", lyrics: "So you're a tough guy..." },
        { id: 15, title: "Watermelon Sugar", artist: "Harry Styles", duration: "2:54", cover: "Harry Styles album cover", lyrics: "Tastes like strawberries on a summer evening..." },
        { id: 16, title: "Don't Start Now", artist: "Dua Lipa", duration: "3:03", cover: "Dua Lipa album cover", lyrics: "Did a full 180, crazy..." },
        { id: 17, title: "Intentions", artist: "Justin Bieber", duration: "3:32", cover: "Justin Bieber album cover", lyrics: "Picture perfect, you don't need no filter..." },
        { id: 18, title: "Dance Monkey", artist: "Tones and I", duration: "3:29", cover: "Tones and I album cover", lyrics: "They say, oh my God, I see the way you shine..." },
        { id: 19, title: "Circles", artist: "Post Malone", duration: "3:35", cover: "Post Malone album cover", lyrics: "Oh, oh, oh, oh, oh, oh..." },
        { id: 20, title: "Savage Love", artist: "Jason Derulo", duration: "2:51", cover: "Jason Derulo album cover", lyrics: "Savage love, did somebody, did somebody break your heart..." },
        // ... dst, hingga baris mencukupi
    ];

    // Hasil filter lagu
    const filteredSongs = songs.filter(song =>
        song.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        song.artist.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Fungsi play/pause lagu
    const handlePlayPause = (song) => {
        if (currentSong && currentSong.id === song.id) {
            setIsPlaying(!isPlaying);
        } else {
            setCurrentSong(song);
            setIsPlaying(true);
        }
        toast({ title: `Memutar: ${song.title}`, description: `oleh ${song.artist}` });
    };

    // Fungsi like lagu
    const handleLike = (song) => {
        toast({ title: "Disimpan!", description: `${song.title} telah ditambahkan ke favorit Anda.` });
    };

    // Komponen utama UI
    return (
        <Layout>
            <div className="space-y-8">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                    <Card className="bg-gradient-to-r from-pink-500 to-rose-600 text-white">
                        <CardHeader>
                            <CardTitle className="text-3xl font-bold">Pusat Musik</CardTitle>
                            <CardDescription className="text-rose-100">Temukan, putar, dan nikmati musik favorit Anda.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="relative max-w-lg">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-rose-200" />
                                <Input
                                    placeholder="Cari lagu atau artis..."
                                    className="pl-10 bg-white/20 border-white/30 placeholder:text-rose-200"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }} className="lg:col-span-2">
                        <Card>
                            <CardHeader>
                                <CardTitle>Hasil Pencarian</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                {filteredSongs.map(song => (
                                    <div key={song.id} className="flex items-center p-2 rounded-lg hover:bg-gray-100 transition-colors">
                                        <img alt={song.cover} className="w-12 h-12 rounded-md object-cover mr-4" src="https://images.unsplash.com/photo-1596132197798-2845a7a6143e" />
                                        <div className="flex-grow">
                                            <p className="font-semibold">{song.title}</p>
                                            <p className="text-sm text-gray-500">{song.artist}</p>
                                        </div>
                                        <p className="text-sm text-gray-500 mr-4">{song.duration}</p>
                                        <Button variant="ghost" size="icon" onClick={() => handleLike(song)}><Heart className="h-4 w-4" /></Button>
                                        <Button variant="ghost" size="icon" onClick={() => handlePlayPause(song)}>
                                            {isPlaying && currentSong?.id === song.id ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                                        </Button>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }} className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Playlist Favorit</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-sm text-gray-500">Belum ada lagu favorit. Klik ikon hati untuk menambahkan.</p>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardHeader>
                                <CardTitle>Rekomendasi</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-2">
                                <Badge>Pop Indonesia</Badge>
                                <Badge>Top Hits Global</Badge>
                                <Badge>Santai</Badge>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>

                {currentSong && (
                    <motion.div initial={{ y: 100, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="fixed bottom-0 left-0 lg:left-80 right-0 bg-white/80 backdrop-blur-lg border-t p-4 shadow-2xl">
                        <div className="flex items-center">
                            <img alt={currentSong.cover} className="w-14 h-14 rounded-md object-cover mr-4" src="https://images.unsplash.com/photo-1621059454394-f723a3f52d9f" />
                            <div>
                                <p className="font-semibold">{currentSong.title}</p>
                                <p className="text-sm text-gray-500">{currentSong.artist}</p>
                            </div>
                            <div className="flex-grow flex items-center justify-center gap-4 mx-8">
                                <Button variant="ghost" size="icon"><SkipBack className="h-5 w-5" /></Button>
                                <Button size="icon" className="w-12 h-12 rounded-full" onClick={() => setIsPlaying(!isPlaying)}>
                                    {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                                </Button>
                                <Button variant="ghost" size="icon"><SkipForward className="h-5 w-5" /></Button>
                            </div>
                            <div className="flex items-center gap-4">
                                <Button variant="ghost" size="icon" onClick={() => setShowLyrics(!showLyrics)}><Mic2 className="h-5 w-5" /></Button>
                                <Volume2 className="h-5 w-5" />
                                <Slider defaultValue={[50]} max={100} step={1} className="w-24" />
                            </div>
                        </div>
                        <div className="absolute top-[-8px] left-0 w-full">
                            <Slider defaultValue={[30]} max={100} step={1} />
                        </div>
                    </motion.div>
                )}

                {showLyrics && currentSong && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center" onClick={() => setShowLyrics(false)}>
                        <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white rounded-lg p-8 max-w-lg w-full text-center relative" onClick={(e) => e.stopPropagation()}>
                            <Button variant="ghost" size="icon" className="absolute top-2 right-2" onClick={() => setShowLyrics(false)}><X className="h-5 w-5" /></Button>
                            <h3 className="text-2xl font-bold mb-2">{currentSong.title}</h3>
                            <p className="text-gray-600 mb-6">{currentSong.artist}</p>
                            <p className="whitespace-pre-line text-lg leading-relaxed">{currentSong.lyrics}</p>
                        </motion.div>
                    </motion.div>
                )}
            </div>
        </Layout>
    );
};

export default MusicPage;